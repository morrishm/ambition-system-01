/* :root {
    --primary-color: #0A4D8F;
    --secondary-color: #E9ECEF;
    --accent-color: #FFA500;
    --text-light: #FFFFFF;
    --text-dark: #212529; 
    --text-gray: #495057; 
    --nav-height: 70px;
    --font-primary: 'Montserrat', sans-serif;
    --font-secondary: 'Open Sans', sans-serif;
    --success-color: #28a745;
    --error-color: #dc3545;
    --warning-color: #ffc107;
} */


/* :root {
    --primary-color: #F8F9FA;
    --secondary-color: #6C757D;
    --accent-color: #28A745;
    --text-light: #FFFFFF;
    --text-dark: #212529;
    --text-gray: #495057;
    --nav-height: 70px;
    --font-primary: 'Montserrat', sans-serif;
    --font-secondary: 'Open Sans', sans-serif;
    --success-color: #28a745;
    --error-color: #dc3545;
    --warning-color: #ffc107;
} */
